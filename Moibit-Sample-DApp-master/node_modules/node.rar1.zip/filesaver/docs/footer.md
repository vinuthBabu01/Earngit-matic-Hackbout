

Tests
-----

```
npm install && npm test
```

Build API docs
--------------

```
npm install && npm run build-docs
```


<br><br>

---

© 2014 [jacoborus](https://github.com/jacoborus)

Released under [MIT License](https://raw.github.com/jacoborus/node-filesaver/master/LICENSE)