oauth-sign
==========

OAuth 1 signing. Formerly a vendor lib in mikeal/request, now a standalone module. 

## Supported Method Signatures

- HMAC-SHA1
- HMAC-SHA256
- RSA-SHA1
- PLAINTEXT