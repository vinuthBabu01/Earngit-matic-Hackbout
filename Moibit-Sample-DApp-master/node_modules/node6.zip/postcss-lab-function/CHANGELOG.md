# Changes to PostCSS Lab Function

### 2.0.1 (September 18, 2018)

- Updated: PostCSS Values Parser 2.0.0

### 2.0.0 (September 17, 2018)

- Updated: Support for PostCSS 7+
- Updated: Support for Node 6+

### 1.1.0 (July 24, 2018)

- Added: Support for `gray(a / b)` as `lab(a 0 0 / b)`

### 1.0.1 (May 11, 2018)

- Fixed: Values beyond the acceptable 0-255 RGB range

### 1.0.0 (May 11, 2018)

- Initial version
