# Changes to PostCSS Environment Variables

### 2.0.2 (September 20, 2018)

- Updated: Do not break on an empty importFrom object

### 2.0.1 (September 18, 2018)

- Updated: Support for PostCSS Values Parser 2

### 2.0.0 (September 17, 2018)

- Updated: Support for PostCSS 7+
- Updated: Support for Node 6+
- Updated: Changed `variables` option to `importFrom` option

### 1.0.0 (April 28, 2018)

- Initial version
