# 4.0.0-rc.0

* Initial commit. This module was previously part of other cssnano modules and
  has been extracted out.
