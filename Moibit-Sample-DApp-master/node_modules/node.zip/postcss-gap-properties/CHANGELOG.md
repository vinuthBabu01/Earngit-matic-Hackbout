# Changes to PostCSS Gap Properties

### 2.0.0 (September 17, 2018)

- Updated: Support for PostCSS v7+
- Updated: Support for Node v6+

### 1.0.0 (April 30, 2018)

- Initial version
