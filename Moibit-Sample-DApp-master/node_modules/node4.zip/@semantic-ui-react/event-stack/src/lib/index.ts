import EventStack from './EventStack'

export const instance = new EventStack()
