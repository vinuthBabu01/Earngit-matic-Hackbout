import EventStack from './EventStack';
export declare const instance: EventStack;
