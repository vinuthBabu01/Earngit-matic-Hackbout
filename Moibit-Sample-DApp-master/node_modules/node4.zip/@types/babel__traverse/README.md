# Installation
> `npm install --save @types/babel__traverse`

# Summary
This package contains type definitions for @babel/traverse (https://github.com/babel/babel/tree/master/packages/babel-traverse).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__traverse.

### Additional Details
 * Last updated: Thu, 20 Feb 2020 18:29:26 GMT
 * Dependencies: [@types/babel__types](https://npmjs.com/package/@types/babel__types)
 * Global values: none

# Credits
These definitions were written by [Troy Gerwien](https://github.com/yortus), [Marvin Hagemeister](https://github.com/marvinhagemeister), [Ryan Petrich](https://github.com/rpetrich), [Melvin Groenhoff](https://github.com/mgroenhoff), and [Dean L.](https://github.com/dlgrit).
