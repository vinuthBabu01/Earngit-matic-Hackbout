# Installation
> `npm install --save @types/istanbul-reports`

# Summary
This package contains type definitions for istanbul-reports ( https://github.com/istanbuljs/istanbuljs ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/istanbul-reports

Additional Details
 * Last updated: Wed, 17 Apr 2019 17:14:08 GMT
 * Dependencies: @types/istanbul-lib-report, @types/istanbul-lib-coverage
 * Global values: none

# Credits
These definitions were written by Jason Cheatham <https://github.com/jason0x43>.
