# Installation
> `npm install --save @types/parse-json`

# Summary
This package contains type definitions for parse-json (https://github.com/sindresorhus/parse-json).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/parse-json

Additional Details
 * Last updated: Tue, 14 Nov 2017 00:30:05 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by mrmlnc <https://github.com/mrmlnc>.
