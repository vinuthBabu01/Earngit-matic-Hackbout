# Changes to PostCSS Place Properties

### 4.0.1 (September 18, 2018)

- Updated: PostCSS Values Parser 2 (patch for this project)

### 4.0.0 (September 17, 2018)

- Updated: Support for PostCSS v7+
- Updated: Support for Node v6+

### 3.0.1 (May 8, 2018)

- Updated: `postcss-values-parser` to v1.5.0 (major)
- Updated: `postcss` to v6.0.22 (patch)

### 2.0.0 (June 30, 2017)

- Added: Node 4+ compatibility
- Added: PostCSS 6+ compatibility

### 1.0.2 (December 8, 2016)

- Updated: Use destructing assignment on plugin options
- Updated: Use template literals

### 1.0.1 (December 6, 2016)

- Updated: boilerplate conventions (`postcss-tape`)

### 1.0.0 (November 25, 2016)

- Initial version
