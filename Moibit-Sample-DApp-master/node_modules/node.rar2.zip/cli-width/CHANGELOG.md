# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="2.2.0"></a>
# [2.2.0](https://github.com/knownasilya/cli-width/compare/v2.1.1...v2.2.0) (2017-08-22)


### Features

* return default if env is 0 ([1833baf](https://github.com/knownasilya/cli-width/commit/1833baf)), closes [#9](https://github.com/knownasilya/cli-width/issues/9)



<a name="2.1.1"></a>
## [2.1.1](https://github.com/knownasilya/cli-width/compare/v2.1.0...v2.1.1) (2017-08-22)
