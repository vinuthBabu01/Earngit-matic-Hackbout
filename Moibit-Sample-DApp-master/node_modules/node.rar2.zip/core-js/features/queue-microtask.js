var parent = require('../stable/queue-microtask');

module.exports = parent;
