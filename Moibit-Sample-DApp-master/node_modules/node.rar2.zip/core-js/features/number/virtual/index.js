var parent = require('../../../es/number/virtual');

module.exports = parent;
