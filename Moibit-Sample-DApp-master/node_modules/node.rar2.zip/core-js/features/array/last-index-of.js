var parent = require('../../es/array/last-index-of');

module.exports = parent;
