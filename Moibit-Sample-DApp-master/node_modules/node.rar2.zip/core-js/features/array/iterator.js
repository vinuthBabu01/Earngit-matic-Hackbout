var parent = require('../../es/array/iterator');

module.exports = parent;
