var parent = require('../../es/array/map');

module.exports = parent;
