var parent = require('../../es/array/splice');

module.exports = parent;
