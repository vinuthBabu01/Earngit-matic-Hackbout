var parent = require('../../es/object/to-string');

module.exports = parent;
