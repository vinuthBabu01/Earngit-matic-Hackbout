require('../../modules/esnext.object.iterate-entries');
var path = require('../../internals/path');

module.exports = path.Object.iterateEntries;
