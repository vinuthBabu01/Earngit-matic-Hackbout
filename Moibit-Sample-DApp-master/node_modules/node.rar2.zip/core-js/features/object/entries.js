var parent = require('../../es/object/entries');

module.exports = parent;
