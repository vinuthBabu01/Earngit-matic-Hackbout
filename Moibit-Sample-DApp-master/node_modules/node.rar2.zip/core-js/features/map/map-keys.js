require('../../modules/es.map');
require('../../modules/esnext.map.map-keys');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Map', 'mapKeys');
