var parent = require('../../es/instance/splice');

module.exports = parent;
