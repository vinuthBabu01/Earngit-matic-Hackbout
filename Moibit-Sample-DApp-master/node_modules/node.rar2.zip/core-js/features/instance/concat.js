var parent = require('../../es/instance/concat');

module.exports = parent;
