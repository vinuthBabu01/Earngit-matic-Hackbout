var parent = require('../../es/instance/bind');

module.exports = parent;
