var parent = require('../../es/instance/flat-map');

module.exports = parent;
