var parent = require('../../es/instance/reduce');

module.exports = parent;
