var parent = require('../../es/instance/reduce-right');

module.exports = parent;
