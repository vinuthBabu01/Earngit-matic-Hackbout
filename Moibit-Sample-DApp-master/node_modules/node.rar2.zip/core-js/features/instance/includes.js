var parent = require('../../es/instance/includes');

module.exports = parent;
