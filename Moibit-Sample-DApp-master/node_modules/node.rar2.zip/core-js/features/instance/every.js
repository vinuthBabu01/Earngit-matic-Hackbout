var parent = require('../../es/instance/every');

module.exports = parent;
