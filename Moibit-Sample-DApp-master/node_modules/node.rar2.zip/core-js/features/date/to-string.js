var parent = require('../../es/date/to-string');

module.exports = parent;
