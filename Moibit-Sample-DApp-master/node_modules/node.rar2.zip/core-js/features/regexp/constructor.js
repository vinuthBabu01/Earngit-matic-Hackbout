var parent = require('../../es/regexp/constructor');

module.exports = parent;
