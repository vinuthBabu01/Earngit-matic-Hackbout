var parent = require('../../es/regexp/sticky');

module.exports = parent;
