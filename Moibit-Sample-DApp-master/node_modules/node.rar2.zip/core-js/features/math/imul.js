var parent = require('../../es/math/imul');

module.exports = parent;
