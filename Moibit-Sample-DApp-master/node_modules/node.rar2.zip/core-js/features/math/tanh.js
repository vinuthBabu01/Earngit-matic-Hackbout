var parent = require('../../es/math/tanh');

module.exports = parent;
