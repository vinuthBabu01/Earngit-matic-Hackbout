var parent = require('../../es/math/fround');

module.exports = parent;
