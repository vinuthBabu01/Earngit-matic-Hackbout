var parent = require('../../es/math/sign');

module.exports = parent;
