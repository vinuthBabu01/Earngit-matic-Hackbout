var parent = require('../../es/math/cbrt');

module.exports = parent;
