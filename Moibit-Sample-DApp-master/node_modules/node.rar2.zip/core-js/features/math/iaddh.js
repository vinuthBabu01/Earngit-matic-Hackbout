require('../../modules/esnext.math.iaddh');
var path = require('../../internals/path');

module.exports = path.Math.iaddh;
