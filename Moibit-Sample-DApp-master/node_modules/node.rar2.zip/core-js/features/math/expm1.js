var parent = require('../../es/math/expm1');

module.exports = parent;
